#include "stdio.h"
#include "calc_mul.h"

int main( void )
{
	int a = 5 , b = 6, c = 11;
	printf( "Result = %d\r\n", c );
	c = calc_mul ( a, b );
	printf( "Result = %d\r\n", c );
	return 0;
}

