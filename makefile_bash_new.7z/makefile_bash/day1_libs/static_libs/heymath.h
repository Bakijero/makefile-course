

int add(int, int); //adds two integers
int sub(int, int); //subtracts second integer from first