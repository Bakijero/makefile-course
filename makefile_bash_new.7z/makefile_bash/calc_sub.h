int calc_sub( int x, int y );

