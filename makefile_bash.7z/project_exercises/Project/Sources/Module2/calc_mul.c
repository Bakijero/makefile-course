#include "calc_mul.h"

#include "stdio.h"

int calc_mul( int x, int y )
{
	int res = 0;
	/* Update  output text for amend */
	res = x * y;
	printf( "Result = %d\r\n",  res );
	return res;
}

