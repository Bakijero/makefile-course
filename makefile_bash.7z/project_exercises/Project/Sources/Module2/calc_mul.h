int calc_mul( int x, int y );

