#include "stdio.h"
#include "calc_add.h"
#include "calc_sub.h"
#include "calc_mul.h"


int main( void )
{
	int a = 5 , b = 6;
	int s = 0, d = 0, p = 0;
	printf( "Result = %d\r\n", s );
	s = calc_add ( a, b );
	printf( "Sum = %d\r\n", s );
	d = calc_sub ( a, b );
	printf( "Diff = %d\r\n", d );
	p = calc_mul ( a, b );
	printf( "Product = %d\r\n",p );
	return 0;
}

